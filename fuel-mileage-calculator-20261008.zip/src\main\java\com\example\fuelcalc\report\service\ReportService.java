package com.example.fuelcalc.report.service;

import com.example.fuelcalc.common.config.CacheConfig;
import com.example.fuelcalc.common.exception.ResourceNotFoundException;
import com.example.fuelcalc.report.domain.ReportGenerator;
import com.example.fuelcalc.report.domain.ReportType;
import com.example.fuelcalc.vehicle.repository.VehicleRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    private final Map<ReportType, ReportGenerator> generators = new EnumMap<>(ReportType.class);
    private final VehicleRepository vehicleRepository;

    public ReportService(List<ReportGenerator> generatorList, VehicleRepository vehicleRepository) {
        generatorList.forEach(g -> generators.put(g.type(), g));
        this.vehicleRepository = vehicleRepository;
    }

    @Cacheable(value = CacheConfig.REPORTS, key = "#type + ':' + #vehicleId + ':' + #from + ':' + #to")
    public Map<String, Object> generate(ReportType type, Long vehicleId, LocalDate from, LocalDate to) {
        if (!vehicleRepository.existsById(vehicleId)) {
            throw new ResourceNotFoundException("Vehicle", vehicleId);
        }
        return generators.get(type).generate(vehicleId, from, to);
    }
}