package com.example.fuelcalc.fuellog.api;

import com.example.fuelcalc.fuellog.api.dto.FuelEntryRequest;
import com.example.fuelcalc.fuellog.api.dto.FuelEntryResponse;
import com.example.fuelcalc.fuellog.domain.FuelEntry;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface FuelEntryMapper {

    @Mapping(target = "vehicle", ignore = true)
    @Mapping(target = "distance", ignore = true)
    @Mapping(target = "mileage", ignore = true)
    @Mapping(target = "totalCost", ignore = true)
    FuelEntry toEntity(FuelEntryRequest request);

    @Mapping(target = "vehicleId", source = "vehicle.id")
    FuelEntryResponse toResponse(FuelEntry entry);
}