import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import Header from './components/Header.jsx';
import Tabs from './components/Tabs.jsx';
import Dashboard from './components/Dashboard.jsx';
import LogForm from './components/LogForm.jsx';
import History from './components/History.jsx';
import Calculator from './components/Calculator.jsx';
import VehicleModal from './components/VehicleModal.jsx';
import Toast from './components/Toast.jsx';

export default function App() {
  const [vehicles, setVehicles] = useState([]);
  const [vehicleId, setVehicleId] = useState(() => Number(localStorage.getItem('fuel.vehicleId')) || null);
  const [tab, setTab] = useState('dashboard');
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [currency, setCurrency] = useState('INR');

  const notify = useCallback((message, isError = false) => setToast({ message, isError, id: Date.now() }), []);
  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);

  const loadVehicles = useCallback(async () => {
    try {
      const page = await api('/vehicles?size=100&sort=name');
      const list = page.content || [];
      setVehicles(list);
      if (list.length && !list.some((v) => v.id === vehicleId)) setVehicleId(list[0].id);
      if (!list.length) setVehicleId(null);
    } catch (err) {
      notify(err.message, true);
    }
  }, [vehicleId, notify]);

  useEffect(() => { loadVehicles(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (vehicleId) localStorage.setItem('fuel.vehicleId', vehicleId);
  }, [vehicleId]);

  const vehicle = vehicles.find((v) => v.id === vehicleId);

  return (
    <>
      <Header
        vehicles={vehicles}
        vehicleId={vehicleId}
        onSelect={setVehicleId}
        onAddVehicle={() => setModalOpen(true)}
      />
      <Tabs active={tab} onChange={setTab} />

      <main className="container">
        {tab === 'dashboard' && (
          <Dashboard
            vehicle={vehicle}
            refreshKey={refreshKey}
            notify={notify}
            onAddVehicle={() => setModalOpen(true)}
            onCurrency={setCurrency}
          />
        )}
        {tab === 'log' && (
          <LogForm vehicleId={vehicleId} currency={currency} notify={notify} onSaved={refresh} />
        )}
        {tab === 'history' && (
          <History vehicleId={vehicleId} currency={currency} refreshKey={refreshKey} notify={notify} onChanged={refresh} />
        )}
        {tab === 'calculator' && <Calculator notify={notify} />}
      </main>

      {modalOpen && (
        <VehicleModal
          onClose={() => setModalOpen(false)}
          notify={notify}
          onCreated={async (v) => {
            setModalOpen(false);
            await loadVehicles();
            setVehicleId(v.id);
            refresh();
          }}
        />
      )}

      <Toast toast={toast} />
    </>
  );
}