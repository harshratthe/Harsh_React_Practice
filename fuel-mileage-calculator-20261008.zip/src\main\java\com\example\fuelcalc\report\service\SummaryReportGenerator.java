package com.example.fuelcalc.report.service;

import com.example.fuelcalc.common.config.FuelCalcProperties;
import com.example.fuelcalc.fuellog.domain.FuelEntry;
import com.example.fuelcalc.fuellog.repository.FuelEntryRepository;
import com.example.fuelcalc.report.domain.ReportGenerator;
import com.example.fuelcalc.report.domain.ReportType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class SummaryReportGenerator implements ReportGenerator {

    private final FuelEntryRepository entryRepository;
    private final FuelCalcProperties props;

    @Override
    public ReportType type() {
        return ReportType.SUMMARY;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> generate(Long vehicleId, LocalDate from, LocalDate to) {
        List<FuelEntry> entries = entryRepository.findByVehicleIdAndEntryDateBetween(vehicleId, from, to);

        double totalKm = entries.stream().mapToDouble(FuelEntry::getDistance).sum();
        double totalFuel = entries.stream().mapToDouble(FuelEntry::getFuelQuantity).sum();
        double totalCost = entries.stream().mapToDouble(FuelEntry::getTotalCost).sum();
        double best = entries.stream().mapToDouble(FuelEntry::getMileage).max().orElse(0);
        double worst = entries.stream().mapToDouble(FuelEntry::getMileage).min().orElse(0);

        Map<String, Object> report = new LinkedHashMap<>();
        report.put("vehicleId", vehicleId);
        report.put("from", from);
        report.put("to", to);
        report.put("entries", entries.size());
        report.put("totalDistanceKm", round(totalKm));
        report.put("totalFuel", round(totalFuel));
        report.put("totalSpent", round(totalCost));
        report.put("averageMileageKmpl", totalFuel == 0 ? 0 : round(totalKm / totalFuel));
        report.put("bestMileageKmpl", round(best));
        report.put("worstMileageKmpl", round(worst));
        report.put("averageCostPerKm", totalKm == 0 ? 0 : round(totalCost / totalKm));
        report.put("currency", props.defaultCurrency());
        return report;
    }

    private double round(double value) {
        return BigDecimal.valueOf(value).setScale(props.roundingScale(), RoundingMode.HALF_UP).doubleValue();
    }
}