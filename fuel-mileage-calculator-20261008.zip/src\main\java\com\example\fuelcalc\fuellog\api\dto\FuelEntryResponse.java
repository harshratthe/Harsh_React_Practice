package com.example.fuelcalc.fuellog.api.dto;

import java.time.LocalDate;

public record FuelEntryResponse(
        Long id,
        Long vehicleId,
        LocalDate entryDate,
        Double odometerStart,
        Double odometerEnd,
        Double fuelQuantity,
        Double pricePerUnit,
        Double distance,
        Double mileage,
        Double totalCost
) {}