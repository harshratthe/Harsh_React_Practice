package com.example.fuelcalc.calculator.api;

import com.example.fuelcalc.calculator.api.dto.MileageRequest;
import com.example.fuelcalc.calculator.api.dto.MileageResponse;
import com.example.fuelcalc.calculator.api.dto.TripCostRequest;
import com.example.fuelcalc.calculator.api.dto.TripCostResponse;
import com.example.fuelcalc.calculator.domain.CalculationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/calculator")
@RequiredArgsConstructor
@Tag(name = "Calculator", description = "Stateless mileage and trip-cost calculations")
public class CalculatorController {

    private final CalculationService service;

    @PostMapping("/mileage")
    public MileageResponse mileage(@Valid @RequestBody MileageRequest request) {
        return service.calculateMileage(request);
    }

    @PostMapping("/trip-cost")
    public TripCostResponse tripCost(@Valid @RequestBody TripCostRequest request) {
        return service.estimateTripCost(request);
    }
}