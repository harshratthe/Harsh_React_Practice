package com.example.fuelcalc.vehicle.domain;

import com.example.fuelcalc.vehicle.api.dto.VehicleRequest;
import com.example.fuelcalc.vehicle.api.dto.VehicleResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface VehicleService {

    VehicleResponse create(VehicleRequest request);

    VehicleResponse get(Long id);

    Page<VehicleResponse> list(Pageable pageable);

    VehicleResponse update(Long id, VehicleRequest request);

    void delete(Long id);
}