import { api, formToObject } from '../api.js';

export default function VehicleModal({ onClose, onCreated, notify }) {
  async function submit(e) {
    e.preventDefault();
    try {
      const v = await api('/vehicles', {
        method: 'POST',
        body: JSON.stringify(formToObject(e.target)),
      });
      notify('Vehicle added');
      onCreated(v);
    } catch (err) {
      notify(err.message, true);
    }
  }

  return (
    <div
      className="modal"
      role="dialog"
      aria-modal="true"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal-card">
        <div className="modal-head">
          <h3>Add vehicle</h3>
          <button className="btn btn-icon" aria-label="Close" onClick={onClose}>✕</button>
        </div>
        <form className="form" onSubmit={submit}>
          <label>Name
            <input
              type="text"
              name="name"
              maxLength="100"
              placeholder="e.g. Honda City"
              required
              autoFocus
            />
          </label>
          <div className="row">
            <label>Fuel type
              <select name="fuelType" defaultValue="PETROL">
                <option>PETROL</option>
                <option>DIESEL</option>
                <option>CNG</option>
                <option>HYBRID</option>
                <option>ELECTRIC</option>
              </select>
            </label>
            <label>Tank capacity (L)
              <input type="number" name="tankCapacity" step="0.1" min="0" />
            </label>
          </div>
          <button type="submit" className="btn btn-primary btn-block">Save vehicle</button>
        </form>
      </div>
    </div>
  );
}