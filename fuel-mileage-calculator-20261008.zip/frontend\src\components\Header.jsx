import { useEffect, useState } from 'react';

export default function Header({ vehicles, vehicleId, onSelect, onAddVehicle }) {
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('fuel.theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return saved || (prefersDark ? 'dark' : 'light');
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('fuel.theme', theme);
  }, [theme]);

  return (
    <header className="topbar">
      <div className="brand">
        <span className="brand-mark" />
        <span>FuelTrack</span>
      </div>
      <div className="topbar-actions">
        {vehicles.length > 0 && (
          <select
            className="select"
            value={vehicleId ?? ''}
            onChange={(e) => onSelect(Number(e.target.value))}
            aria-label="Select vehicle"
          >
            {vehicles.map((v) => (
              <option key={v.id} value={v.id}>{v.name}</option>
            ))}
          </select>
        )}
        <button className="btn btn-ghost" onClick={onAddVehicle}>+ <span>Vehicle</span></button>
        <button
          className="btn btn-icon"
          aria-label="Toggle theme"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        >
          <span className="icon-sun" />
        </button>
      </div>
    </header>
  );
}