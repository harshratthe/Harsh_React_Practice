package com.example.fuelcalc.calculator.api.dto;

import com.example.fuelcalc.calculator.domain.unit.DistanceUnit;
import com.example.fuelcalc.calculator.domain.unit.VolumeUnit;
import com.example.fuelcalc.vehicle.domain.FuelType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record MileageRequest(
        @NotNull @Positive Double distance,
        @NotNull DistanceUnit distanceUnit,
        @NotNull @Positive Double fuelQuantity,
        @NotNull VolumeUnit volumeUnit,
        @NotNull FuelType fuelType,
        @Positive Double pricePerUnit
) {}