package com.example.fuelcalc.fuellog.domain;

public record FuelEntryLoggedEvent(
        Long vehicleId,
        Long entryId,
        double mileage,
        double odometerEnd
) {}