const TABS = [
  { id: 'dashboard', icon: '▦', label: 'Dashboard' },
  { id: 'log', icon: '＋', label: 'Fill-up' },
  { id: 'history', icon: '≡', label: 'History' },
  { id: 'calculator', icon: '∑', label: 'Calculator' },
];

export default function Tabs({ active, onChange }) {
  return (
    <nav className="tabs" role="tablist">
      {TABS.map((t) => (
        <button
          key={t.id}
          role="tab"
          className={'tab-btn' + (active === t.id ? ' active' : '')}
          onClick={() => onChange(t.id)}
        >
          <span className="tab-icon">{t.icon}</span>
          <span>{t.label}</span>
        </button>
      ))}
    </nav>
  );
}