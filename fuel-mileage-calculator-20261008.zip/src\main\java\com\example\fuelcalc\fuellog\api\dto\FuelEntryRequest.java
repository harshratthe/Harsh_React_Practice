package com.example.fuelcalc.fuellog.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.LocalDate;

public record FuelEntryRequest(
        @NotNull @PastOrPresent LocalDate entryDate,
        @NotNull @PositiveOrZero Double odometerStart,
        @NotNull @Positive Double odometerEnd,
        @NotNull @Positive Double fuelQuantity,
        @NotNull @Positive Double pricePerUnit
) {}