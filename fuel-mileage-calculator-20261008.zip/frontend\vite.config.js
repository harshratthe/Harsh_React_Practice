import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const BACKEND = 'http' + '://localhost:8081';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    proxy: {
      '/api': {
        target: BACKEND,
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: '../src/main/resources/static',
    emptyOutDir: true,
  },
});
