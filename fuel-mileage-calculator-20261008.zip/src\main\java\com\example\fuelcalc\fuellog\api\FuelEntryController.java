package com.example.fuelcalc.fuellog.api;

import com.example.fuelcalc.fuellog.api.dto.FuelEntryRequest;
import com.example.fuelcalc.fuellog.api.dto.FuelEntryResponse;
import com.example.fuelcalc.fuellog.domain.FuelEntryService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/vehicles/{vehicleId}/entries")
@RequiredArgsConstructor
@Tag(name = "Fuel Log", description = "Record and review fill-ups")
public class FuelEntryController {

    private final FuelEntryService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FuelEntryResponse log(@PathVariable Long vehicleId,
                                 @Valid @RequestBody FuelEntryRequest request) {
        return service.log(vehicleId, request);
    }

    @GetMapping
    public Page<FuelEntryResponse> history(
            @PathVariable Long vehicleId,
            @PageableDefault(size = 20, sort = "entryDate", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.history(vehicleId, pageable);
    }

    @DeleteMapping("/{entryId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long vehicleId, @PathVariable Long entryId) {
        service.delete(vehicleId, entryId);
    }
}