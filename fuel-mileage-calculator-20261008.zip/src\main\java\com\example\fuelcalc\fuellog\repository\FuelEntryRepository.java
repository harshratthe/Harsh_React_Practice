package com.example.fuelcalc.fuellog.repository;

import com.example.fuelcalc.fuellog.domain.FuelEntry;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface FuelEntryRepository extends JpaRepository<FuelEntry, Long> {

    Page<FuelEntry> findByVehicleId(Long vehicleId, Pageable pageable);

    List<FuelEntry> findByVehicleIdAndEntryDateBetween(Long vehicleId, LocalDate from, LocalDate to);

    @Query("""
           SELECT EXTRACT(YEAR FROM f.entryDate),
                  EXTRACT(MONTH FROM f.entryDate),
                  SUM(f.distance),
                  SUM(f.fuelQuantity),
                  SUM(f.totalCost)
           FROM FuelEntry f
           WHERE f.vehicle.id = :vehicleId
             AND f.entryDate BETWEEN :from AND :to
           GROUP BY EXTRACT(YEAR FROM f.entryDate), EXTRACT(MONTH FROM f.entryDate)
           ORDER BY EXTRACT(YEAR FROM f.entryDate), EXTRACT(MONTH FROM f.entryDate)
           """)
    List<Object[]> monthlyAggregates(@Param("vehicleId") Long vehicleId,
                                     @Param("from") LocalDate from,
                                     @Param("to") LocalDate to);
}