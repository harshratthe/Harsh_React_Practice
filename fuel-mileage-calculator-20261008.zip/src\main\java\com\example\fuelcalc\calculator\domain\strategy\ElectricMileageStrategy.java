package com.example.fuelcalc.calculator.domain.strategy;

import com.example.fuelcalc.vehicle.domain.FuelType;
import org.springframework.stereotype.Component;

@Component
public class ElectricMileageStrategy implements MileageStrategy {

    @Override
    public boolean supports(FuelType fuelType) {
        return fuelType == FuelType.ELECTRIC;
    }

    @Override
    public double calculate(double distanceKm, double kwh) {
        return distanceKm / kwh;
    }
}