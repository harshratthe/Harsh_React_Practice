package com.example.fuelcalc.calculator.api.dto;

import com.example.fuelcalc.calculator.domain.unit.DistanceUnit;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record TripCostRequest(
        @NotNull @Positive Double distance,
        @NotNull DistanceUnit distanceUnit,
        @NotNull @Positive Double mileageKmpl,
        @NotNull @Positive Double pricePerLitre
) {}