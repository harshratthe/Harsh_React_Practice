package com.example.fuelcalc.vehicle.service;

import com.example.fuelcalc.fuellog.domain.FuelEntryLoggedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ServiceReminderListener {

    @Async
    @EventListener
    public void onFuelLogged(FuelEntryLoggedEvent event) {
        // Future hook: compare event.odometerEnd() with a vehicle's next-service km and notify.
        log.info("Fuel logged for vehicle {} -> mileage {} km/L, odometer {}",
                event.vehicleId(), event.mileage(), event.odometerEnd());
    }
}