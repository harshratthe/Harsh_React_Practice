package com.example.fuelcalc.calculator.service;

import com.example.fuelcalc.calculator.api.dto.MileageRequest;
import com.example.fuelcalc.calculator.api.dto.MileageResponse;
import com.example.fuelcalc.calculator.api.dto.TripCostRequest;
import com.example.fuelcalc.calculator.api.dto.TripCostResponse;
import com.example.fuelcalc.calculator.domain.CalculationService;
import com.example.fuelcalc.calculator.domain.strategy.MileageStrategyResolver;
import com.example.fuelcalc.calculator.domain.unit.DistanceUnit;
import com.example.fuelcalc.calculator.domain.unit.VolumeUnit;
import com.example.fuelcalc.common.config.FuelCalcProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
@RequiredArgsConstructor
public class DefaultCalculationService implements CalculationService {

    private final MileageStrategyResolver resolver;
    private final FuelCalcProperties props;

    @Override
    public MileageResponse calculateMileage(MileageRequest req) {
        double km = req.distanceUnit().toKm(req.distance());
        double litres = req.volumeUnit().toLitre(req.fuelQuantity());

        double kmpl = resolver.resolve(req.fuelType()).calculate(km, litres);
        double milesPerLitre = DistanceUnit.MILE.fromKm(kmpl);
        double gallonsPerLitre = VolumeUnit.US_GALLON.fromLitre(1.0);
        double mpgUs = milesPerLitre / gallonsPerLitre;

        Double totalCost = null;
        Double costPerKm = null;
        if (req.pricePerUnit() != null) {
            totalCost = round(req.fuelQuantity() * req.pricePerUnit());
            costPerKm = round(totalCost / km);
        }

        return MileageResponse.builder()
                .mileageKmpl(round(kmpl))
                .mileageMpgUs(round(mpgUs))
                .mileageL100km(round(100.0 / kmpl))
                .totalCost(totalCost)
                .costPerKm(costPerKm)
                .currency(props.defaultCurrency())
                .build();
    }

    @Override
    public TripCostResponse estimateTripCost(TripCostRequest req) {
        double km = req.distanceUnit().toKm(req.distance());
        double litresNeeded = km / req.mileageKmpl();
        return new TripCostResponse(
                round(litresNeeded),
                round(litresNeeded * req.pricePerLitre()),
                props.defaultCurrency());
    }

    private double round(double value) {
        return BigDecimal.valueOf(value)
                .setScale(props.roundingScale(), RoundingMode.HALF_UP)
                .doubleValue();
    }
}