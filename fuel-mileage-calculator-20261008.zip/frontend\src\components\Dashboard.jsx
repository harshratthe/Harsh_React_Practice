import { useEffect, useState } from 'react';
import { api, fmtMoney, fmtNum, monthName, today } from '../api.js';
import BarChart from './BarChart.jsx';

export default function Dashboard({ vehicle, refreshKey, notify, onAddVehicle, onCurrency }) {
  const [summary, setSummary] = useState(null);
  const [monthly, setMonthly] = useState([]);
  const [recent, setRecent] = useState([]);

  useEffect(() => {
    if (!vehicle) return;
    const from = new Date();
    from.setFullYear(from.getFullYear() - 1);
    const fromStr = from.toISOString().slice(0, 10);

    Promise.all([
      api(`/vehicles/${vehicle.id}/reports/SUMMARY`),
      api(`/vehicles/${vehicle.id}/reports/MONTHLY?from=${fromStr}&to=${today()}`),
      api(`/vehicles/${vehicle.id}/entries?size=10`),
    ])
      .then(([s, m, r]) => {
        setSummary(s);
        setMonthly(m.months || []);
        setRecent((r.content || []).slice().reverse());
        if (s.currency) onCurrency(s.currency);
      })
      .catch((err) => notify(err.message, true));
  }, [vehicle, refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!vehicle) {
    return (
      <section className="tab-panel">
        <div className="empty">
          <h2>Welcome to FuelTrack</h2>
          <p>Add your first vehicle to start tracking mileage and fuel costs.</p>
          <button className="btn btn-primary" onClick={onAddVehicle}>Add a vehicle</button>
        </div>
      </section>
    );
  }

  const cur = summary?.currency || 'INR';

  return (
    <section className="tab-panel">
      <div className="section-head">
        <h2>{vehicle.name}</h2>
        <span className="muted">
          {summary ? `${summary.entries} fill-up${summary.entries === 1 ? '' : 's'}` : ''}
        </span>
      </div>

      <div className="stats-grid">
        <Stat label="Average mileage" value={fmtNum(summary?.averageMileageKmpl, 2)} unit="km/L" accent />
        <Stat label="Total spent" value={fmtMoney(summary?.totalSpent, cur)} />
        <Stat label="Distance" value={fmtNum(summary?.totalDistanceKm, 0)} unit="km" />
        <Stat label="Fuel" value={fmtNum(summary?.totalFuel, 1)} unit="L" />
        <Stat label="Cost per km" value={summary?.averageCostPerKm ? fmtMoney(summary.averageCostPerKm, cur) : '–'} />
        <Stat
          label="Best / Worst"
          value={`${fmtNum(summary?.bestMileageKmpl, 1)} / ${fmtNum(summary?.worstMileageKmpl, 1)}`}
          small
        />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Monthly spend</h3>
          <span className="muted">Last 12 months</span>
        </div>
        {monthly.length ? (
          <BarChart items={monthly.map((m) => ({ label: monthName(m.month), value: m.spent, text: fmtMoney(m.spent, cur) }))} />
        ) : (
          <div className="muted center">No fill-ups yet. Log your first one!</div>
        )}
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Mileage trend</h3>
          <span className="muted">Recent fill-ups</span>
        </div>
        <BarChart
          slim
          items={recent.map((e) => ({ label: e.entryDate.slice(5), value: e.mileage, text: fmtNum(e.mileage, 2) + ' km/L' }))}
        />
      </div>
    </section>
  );
}

function Stat({ label, value, unit, accent, small }) {
  return (
    <div className={'stat-card' + (accent ? ' accent' : '')}>
      <div className="stat-label">{label}</div>
      <div className={'stat-value' + (small ? ' small' : '')}>
        {value}
        {unit && <small> {unit}</small>}
      </div>
    </div>
  );
}