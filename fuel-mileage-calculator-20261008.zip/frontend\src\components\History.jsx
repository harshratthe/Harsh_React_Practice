import { useEffect, useState } from 'react';
import { api, fmtMoney, fmtNum, monthName } from '../api.js';

export default function History({ vehicleId, currency, refreshKey, notify, onChanged }) {
  const [entries, setEntries] = useState([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (!vehicleId) { setEntries([]); return; }
    api(`/vehicles/${vehicleId}/entries?size=100`)
      .then((p) => { setEntries(p.content || []); setTotal(p.totalElements || 0); })
      .catch((err) => notify(err.message, true));
  }, [vehicleId, refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  async function remove(id) {
    if (!confirm('Delete this fill-up?')) return;
    try {
      await api(`/vehicles/${vehicleId}/entries/${id}`, { method: 'DELETE' });
      notify('Deleted');
      onChanged();
    } catch (err) {
      notify(err.message, true);
    }
  }

  return (
    <section className="tab-panel">
      <div className="section-head">
        <h2>Fill-up history</h2>
        <span className="muted">{total ? `${total} total` : ''}</span>
      </div>

      {!entries.length && (
        <div className="empty"><p>No fill-ups recorded for this vehicle yet.</p></div>
      )}

      <div className="list">
        {entries.map((e) => {
          const d = new Date(e.entryDate + 'T00:00:00');
          return (
            <div className="entry" key={e.id}>
              <div className="entry-date">
                <span>{d.getDate()}</span>
                <small>{monthName(d.getMonth() + 1)}</small>
              </div>
              <div className="entry-main">
                <div className="entry-title">{fmtNum(e.mileage, 2)} km/L</div>
                <div className="entry-sub">
                  {fmtNum(e.distance, 0)} km · {fmtNum(e.fuelQuantity, 2)} L · {fmtNum(e.odometerStart, 0)} → {fmtNum(e.odometerEnd, 0)}
                </div>
              </div>
              <div className="entry-right">
                <b>{fmtMoney(e.totalCost, currency)}</b>
                <span className="chip">{fmtMoney(e.pricePerUnit, currency)}/L</span>
                <button className="btn btn-danger" onClick={() => remove(e.id)}>Delete</button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}