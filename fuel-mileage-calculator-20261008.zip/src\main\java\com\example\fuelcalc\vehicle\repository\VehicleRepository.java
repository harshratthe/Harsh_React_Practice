package com.example.fuelcalc.vehicle.repository;

import com.example.fuelcalc.vehicle.domain.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
}