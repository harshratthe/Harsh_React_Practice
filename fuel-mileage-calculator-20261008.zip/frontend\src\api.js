const API = '/api/v1';

export async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const details = body.details?.length ? ' — ' + body.details.join(', ') : '';
    throw new Error((body.message || res.statusText) + details);
  }
  return body;
}

export const today = () => new Date().toISOString().slice(0, 10);
export const monthName = (m) =>
  ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][m - 1];
export const fmtNum = (n, d = 1) => (n == null ? '–' : Number(n).toFixed(d));
export const fmtMoney = (n, currency = 'INR') =>
  n == null
    ? '–'
    : new Intl.NumberFormat(undefined, { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);

export function formToObject(form) {
  const obj = {};
  new FormData(form).forEach((v, k) => {
    obj[k] = v === '' ? null : isNaN(v) ? v : Number(v);
  });
  return obj;
}