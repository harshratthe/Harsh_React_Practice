package com.example.fuelcalc.vehicle.domain;

public enum FuelType {
    PETROL, DIESEL, CNG, ELECTRIC, HYBRID
}