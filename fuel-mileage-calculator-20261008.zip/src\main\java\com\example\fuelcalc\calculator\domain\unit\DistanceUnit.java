package com.example.fuelcalc.calculator.domain.unit;

public enum DistanceUnit {
    KM(1.0),
    MILE(1.609344);

    private final double toKmFactor;

    DistanceUnit(double toKmFactor) {
        this.toKmFactor = toKmFactor;
    }

    public double toKm(double value) {
        return value * toKmFactor;
    }

    public double fromKm(double km) {
        return km / toKmFactor;
    }
}