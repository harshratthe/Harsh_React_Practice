import { useEffect, useState } from 'react';
import { api, fmtMoney, fmtNum, today } from '../api.js';

const empty = () => ({
  entryDate: today(),
  odometerStart: '',
  odometerEnd: '',
  fuelQuantity: '',
  pricePerUnit: localStorage.getItem('fuel.lastPrice') || '',
});

export default function LogForm({ vehicleId, currency, notify, onSaved }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!vehicleId) return;
    api(`/vehicles/${vehicleId}/entries?size=1`)
      .then((p) => {
        const last = p.content?.[0];
        if (last) setForm((f) => ({ ...f, odometerStart: f.odometerStart || last.odometerEnd }));
      })
      .catch(() => {});
  }, [vehicleId]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const km = form.odometerEnd && form.odometerStart ? Number(form.odometerEnd) - Number(form.odometerStart) : 0;
  const fuel = Number(form.fuelQuantity) || 0;
  const price = Number(form.pricePerUnit) || 0;
  const previewOk = km > 0 && fuel > 0;

  async function submit(e) {
    e.preventDefault();
    if (!vehicleId) return notify('Add a vehicle first', true);
    setSaving(true);
    try {
      const body = {
        entryDate: form.entryDate,
        odometerStart: Number(form.odometerStart),
        odometerEnd: Number(form.odometerEnd),
        fuelQuantity: fuel,
        pricePerUnit: price,
      };
      const saved = await api(`/vehicles/${vehicleId}/entries`, { method: 'POST', body: JSON.stringify(body) });
      localStorage.setItem('fuel.lastPrice', price);
      notify(`Saved — ${fmtNum(saved.mileage, 2)} km/L`);
      setForm({ ...empty(), odometerStart: saved.odometerEnd, pricePerUnit: price });
      onSaved();
    } catch (err) {
      notify(err.message, true);
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="tab-panel">
      <div className="card form-card">
        <h2>Log a fill-up</h2>
        <form className="form" onSubmit={submit}>
          <label>Date
            <input type="date" value={form.entryDate} onChange={set('entryDate')} required />
          </label>
          <div className="row">
            <label>Odometer start (km)
              <input type="number" step="0.1" min="0" value={form.odometerStart} onChange={set('odometerStart')} required />
            </label>
            <label>Odometer end (km)
              <input type="number" step="0.1" min="0" value={form.odometerEnd} onChange={set('odometerEnd')} required />
            </label>
          </div>
          <div className="row">
            <label>Fuel filled (L)
              <input type="number" step="0.01" min="0.01" value={form.fuelQuantity} onChange={set('fuelQuantity')} required />
            </label>
            <label>Price per litre
              <input type="number" step="0.01" min="0.01" value={form.pricePerUnit} onChange={set('pricePerUnit')} required />
            </label>
          </div>
          {previewOk && (
            <div className="preview">
              <span>Distance: <b>{fmtNum(km, 1)}</b> km</span>
              <span>Mileage: <b>{fmtNum(km / fuel, 2)}</b> km/L</span>
              <span>Cost: <b>{price ? fmtMoney(fuel * price, currency) : '–'}</b></span>
            </div>
          )}
          <button type="submit" className="btn btn-primary btn-block" disabled={saving}>
            {saving ? 'Saving…' : 'Save fill-up'}
          </button>
        </form>
      </div>
    </section>
  );
}