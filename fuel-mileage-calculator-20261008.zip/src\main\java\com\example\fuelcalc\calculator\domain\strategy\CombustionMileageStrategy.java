package com.example.fuelcalc.calculator.domain.strategy;

import com.example.fuelcalc.vehicle.domain.FuelType;
import org.springframework.stereotype.Component;

import java.util.EnumSet;
import java.util.Set;

@Component
public class CombustionMileageStrategy implements MileageStrategy {

    private static final Set<FuelType> SUPPORTED =
            EnumSet.of(FuelType.PETROL, FuelType.DIESEL, FuelType.CNG, FuelType.HYBRID);

    @Override
    public boolean supports(FuelType fuelType) {
        return SUPPORTED.contains(fuelType);
    }

    @Override
    public double calculate(double distanceKm, double litres) {
        return distanceKm / litres;
    }
}