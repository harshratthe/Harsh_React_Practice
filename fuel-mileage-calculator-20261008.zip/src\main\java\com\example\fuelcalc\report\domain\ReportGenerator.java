package com.example.fuelcalc.report.domain;

import java.time.LocalDate;
import java.util.Map;

public interface ReportGenerator {

    ReportType type();

    Map<String, Object> generate(Long vehicleId, LocalDate from, LocalDate to);
}