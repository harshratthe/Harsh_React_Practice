package com.example.fuelcalc.report.domain;

public enum ReportType {
    SUMMARY, MONTHLY
}