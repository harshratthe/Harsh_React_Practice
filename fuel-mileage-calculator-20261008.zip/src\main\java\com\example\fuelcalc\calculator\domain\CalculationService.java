package com.example.fuelcalc.calculator.domain;

import com.example.fuelcalc.calculator.api.dto.MileageRequest;
import com.example.fuelcalc.calculator.api.dto.MileageResponse;
import com.example.fuelcalc.calculator.api.dto.TripCostRequest;
import com.example.fuelcalc.calculator.api.dto.TripCostResponse;

public interface CalculationService {

    MileageResponse calculateMileage(MileageRequest request);

    TripCostResponse estimateTripCost(TripCostRequest request);
}