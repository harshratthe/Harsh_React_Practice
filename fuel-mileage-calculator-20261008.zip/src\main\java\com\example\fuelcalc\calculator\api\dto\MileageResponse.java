package com.example.fuelcalc.calculator.api.dto;

import lombok.Builder;

@Builder
public record MileageResponse(
        double mileageKmpl,
        double mileageMpgUs,
        double mileageL100km,
        Double totalCost,
        Double costPerKm,
        String currency
) {}