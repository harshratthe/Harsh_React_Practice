import { useEffect, useState } from 'react';

export default function Toast({ toast }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!toast) return;
    setVisible(true);
    const t = setTimeout(() => setVisible(false), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  if (!toast || !visible) return null;

  return (
    <div className={'toast' + (toast.isError ? ' error' : '')}>
      {toast.message}
    </div>
  );
}