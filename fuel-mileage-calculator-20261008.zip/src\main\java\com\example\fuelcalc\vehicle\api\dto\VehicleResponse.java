package com.example.fuelcalc.vehicle.api.dto;

import com.example.fuelcalc.vehicle.domain.FuelType;

import java.time.Instant;

public record VehicleResponse(
        Long id,
        String name,
        FuelType fuelType,
        Double tankCapacity,
        Instant createdAt
) {}