package com.example.fuelcalc.fuellog.domain;

import com.example.fuelcalc.fuellog.api.dto.FuelEntryRequest;
import com.example.fuelcalc.fuellog.api.dto.FuelEntryResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FuelEntryService {

    FuelEntryResponse log(Long vehicleId, FuelEntryRequest request);

    Page<FuelEntryResponse> history(Long vehicleId, Pageable pageable);

    void delete(Long vehicleId, Long entryId);
}