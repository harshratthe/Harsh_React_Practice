package com.example.fuelcalc.common.config;

import com.example.fuelcalc.calculator.domain.unit.DistanceUnit;
import com.example.fuelcalc.calculator.domain.unit.VolumeUnit;
import org.springframework.boot.context.properties.ConfigurationProperties;
import com.example.fuelcalc.common.config.FuelCalcProperties;

@ConfigurationProperties(prefix = "fuelcalc")
public record FuelCalcProperties(
        String defaultCurrency,
        DistanceUnit defaultDistanceUnit,
        VolumeUnit defaultVolumeUnit,
        int roundingScale
) {}