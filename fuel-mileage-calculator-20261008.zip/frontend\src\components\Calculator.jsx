import { useState } from 'react';
import { api, fmtMoney, fmtNum, formToObject } from '../api.js';

const FUEL_TYPES = ['PETROL', 'DIESEL', 'CNG', 'HYBRID', 'ELECTRIC'];

export default function Calculator({ notify }) {
  const [mileage, setMileage] = useState(null);
  const [trip, setTrip] = useState(null);

  async function calcMileage(e) {
    e.preventDefault();
    try {
      setMileage(await api('/calculator/mileage', { method: 'POST', body: JSON.stringify(formToObject(e.target)) }));
    } catch (err) { notify(err.message, true); }
  }

  async function calcTrip(e) {
    e.preventDefault();
    try {
      setTrip(await api('/calculator/trip-cost', { method: 'POST', body: JSON.stringify(formToObject(e.target)) }));
    } catch (err) { notify(err.message, true); }
  }

  return (
    <section className="tab-panel">
      <div className="two-col">
        <div className="card form-card">
          <h2>Quick mileage</h2>
          <form className="form" onSubmit={calcMileage}>
            <div className="row">
              <label>Distance<input type="number" name="distance" step="0.1" min="0.1" required /></label>
              <label>Unit
                <select name="distanceUnit" defaultValue="KM">
                  <option value="KM">km</option><option value="MILE">miles</option>
                </select>
              </label>
            </div>
            <div className="row">
              <label>Fuel<input type="number" name="fuelQuantity" step="0.01" min="0.01" required /></label>
              <label>Unit
                <select name="volumeUnit" defaultValue="LITRE">
                  <option value="LITRE">litres</option><option value="US_GALLON">US gallons</option>
                  <option value="UK_GALLON">UK gallons</option><option value="KWH">kWh</option>
                </select>
              </label>
            </div>
            <div className="row">
              <label>Fuel type
                <select name="fuelType" defaultValue="PETROL">
                  {FUEL_TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </label>
              <label>Price per unit (optional)<input type="number" name="pricePerUnit" step="0.01" min="0" /></label>
            </div>
            <button type="submit" className="btn btn-primary btn-block">Calculate</button>
          </form>
          {mileage && (
            <div className="result">
              <div><span>Mileage</span><b>{fmtNum(mileage.mileageKmpl, 2)} km/L</b></div>
              <div><span>US MPG</span><b>{fmtNum(mileage.mileageMpgUs, 1)}</b></div>
              <div><span>L / 100 km</span><b>{fmtNum(mileage.mileageL100km, 2)}</b></div>
              {mileage.totalCost != null && <div><span>Total cost</span><b>{fmtMoney(mileage.totalCost, mileage.currency)}</b></div>}
              {mileage.costPerKm != null && <div><span>Cost per km</span><b>{fmtMoney(mileage.costPerKm, mileage.currency)}</b></div>}
            </div>
          )}
        </div>

        <div className="card form-card">
          <h2>Trip cost</h2>
          <form className="form" onSubmit={calcTrip}>
            <div className="row">
              <label>Trip distance<input type="number" name="distance" step="0.1" min="0.1" required /></label>
              <label>Unit
                <select name="distanceUnit" defaultValue="KM">
                  <option value="KM">km</option><option value="MILE">miles</option>
                </select>
              </label>
            </div>
            <div className="row">
              <label>Your mileage (km/L)<input type="number" name="mileageKmpl" step="0.01" min="0.1" required /></label>
              <label>Price per litre<input type="number" name="pricePerLitre" step="0.01" min="0.01" required /></label>
            </div>
            <button type="submit" className="btn btn-primary btn-block">Estimate</button>
          </form>
          {trip && (
            <div className="result">
              <div><span>Fuel needed</span><b>{fmtNum(trip.fuelNeededLitres, 2)} L</b></div>
              <div><span>Estimated cost</span><b>{fmtMoney(trip.estimatedCost, trip.currency)}</b></div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}