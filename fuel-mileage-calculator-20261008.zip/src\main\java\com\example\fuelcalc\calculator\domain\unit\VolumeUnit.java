package com.example.fuelcalc.calculator.domain.unit;

public enum VolumeUnit {
    LITRE(1.0),
    US_GALLON(3.785411784),
    UK_GALLON(4.54609),
    KWH(1.0);

    private final double toLitreFactor;

    VolumeUnit(double toLitreFactor) {
        this.toLitreFactor = toLitreFactor;
    }

    public double toLitre(double value) {
        return value * toLitreFactor;
    }

    public double fromLitre(double litres) {
        return litres / toLitreFactor;
    }
}