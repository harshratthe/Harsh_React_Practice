package com.example.fuelcalc.calculator.domain.strategy;

import com.example.fuelcalc.vehicle.domain.FuelType;

public interface MileageStrategy {

    boolean supports(FuelType fuelType);

    double calculate(double distanceKm, double fuelBaseUnits);
}