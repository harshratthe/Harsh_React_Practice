package com.example.fuelcalc.vehicle.api;

import com.example.fuelcalc.vehicle.api.dto.VehicleRequest;
import com.example.fuelcalc.vehicle.api.dto.VehicleResponse;
import com.example.fuelcalc.vehicle.domain.Vehicle;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface VehicleMapper {

    Vehicle toEntity(VehicleRequest request);

    VehicleResponse toResponse(Vehicle vehicle);

    void update(@MappingTarget Vehicle vehicle, VehicleRequest request);
}