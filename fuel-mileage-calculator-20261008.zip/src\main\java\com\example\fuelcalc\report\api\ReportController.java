package com.example.fuelcalc.report.api;

import com.example.fuelcalc.report.domain.ReportType;
import com.example.fuelcalc.report.service.ReportService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/vehicles/{vehicleId}/reports")
@RequiredArgsConstructor
@Tag(name = "Reports", description = "Summary and monthly fuel reports")
public class ReportController {

    private static final LocalDate DEFAULT_FROM = LocalDate.of(2000, 1, 1);

    private final ReportService service;

    @GetMapping("/{type}")
    public Map<String, Object> report(
            @PathVariable Long vehicleId,
            @PathVariable ReportType type,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return service.generate(type,
                vehicleId,
                from == null ? DEFAULT_FROM : from,
                to == null ? LocalDate.now() : to);
    }
}