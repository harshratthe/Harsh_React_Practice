import { useEffect, useState } from 'react';

export default function BarChart({ items, slim = false }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(false);
    const id = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(id);
  }, [items]);

  if (!items.length) return null;
  const max = Math.max(...items.map((i) => i.value || 0)) || 1;

  return (
    <div className={'bars' + (slim ? ' bars-slim' : '')}>
      {items.map((i, idx) => (
        <div className="bar" key={idx}>
          <div
            className="bar-fill"
            data-value={i.text}
            style={{ height: ready ? Math.max(4, (i.value / max) * 100) + '%' : '0%' }}
          />
          <div className="bar-label">{i.label}</div>
        </div>
      ))}
    </div>
  );
}