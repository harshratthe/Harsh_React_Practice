package com.example.fuelcalc.fuellog.service;

import com.example.fuelcalc.common.config.CacheConfig;
import com.example.fuelcalc.common.exception.BusinessRuleException;
import com.example.fuelcalc.common.exception.ResourceNotFoundException;
import com.example.fuelcalc.fuellog.api.FuelEntryMapper;
import com.example.fuelcalc.fuellog.api.dto.FuelEntryRequest;
import com.example.fuelcalc.fuellog.api.dto.FuelEntryResponse;
import com.example.fuelcalc.fuellog.domain.FuelEntry;
import com.example.fuelcalc.fuellog.domain.FuelEntryLoggedEvent;
import com.example.fuelcalc.fuellog.domain.FuelEntryService;
import com.example.fuelcalc.fuellog.repository.FuelEntryRepository;
import com.example.fuelcalc.vehicle.domain.Vehicle;
import com.example.fuelcalc.vehicle.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class DefaultFuelEntryService implements FuelEntryService {

    private final FuelEntryRepository entryRepository;
    private final VehicleRepository vehicleRepository;
    private final FuelEntryMapper mapper;
    private final ApplicationEventPublisher events;

    @Override
    @CacheEvict(value = CacheConfig.REPORTS, allEntries = true)
    public FuelEntryResponse log(Long vehicleId, FuelEntryRequest request) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle", vehicleId));

        if (request.odometerEnd() <= request.odometerStart()) {
            throw new BusinessRuleException("Odometer end must be greater than odometer start");
        }

        FuelEntry entry = mapper.toEntity(request);
        entry.attachTo(vehicle);
        entry.computeDerivedValues();

        FuelEntry saved = entryRepository.save(entry);

        events.publishEvent(new FuelEntryLoggedEvent(
                vehicleId, saved.getId(), saved.getMileage(), saved.getOdometerEnd()));

        return mapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<FuelEntryResponse> history(Long vehicleId, Pageable pageable) {
        if (!vehicleRepository.existsById(vehicleId)) {
            throw new ResourceNotFoundException("Vehicle", vehicleId);
        }
        return entryRepository.findByVehicleId(vehicleId, pageable).map(mapper::toResponse);
    }

    @Override
    @CacheEvict(value = CacheConfig.REPORTS, allEntries = true)
    public void delete(Long vehicleId, Long entryId) {
        FuelEntry entry = entryRepository.findById(entryId)
                .orElseThrow(() -> new ResourceNotFoundException("FuelEntry", entryId));

        if (!entry.getVehicle().getId().equals(vehicleId)) {
            throw new BusinessRuleException("Entry " + entryId + " does not belong to vehicle " + vehicleId);
        }
        entryRepository.delete(entry);
    }
}