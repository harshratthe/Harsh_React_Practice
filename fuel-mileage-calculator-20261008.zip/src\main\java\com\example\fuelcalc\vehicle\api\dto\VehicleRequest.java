package com.example.fuelcalc.vehicle.api.dto;

import com.example.fuelcalc.vehicle.domain.FuelType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record VehicleRequest(
        @NotBlank @Size(max = 100) String name,
        @NotNull FuelType fuelType,
        @Positive Double tankCapacity
) {}