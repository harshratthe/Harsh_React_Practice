package com.example.fuelcalc.vehicle.service;

import com.example.fuelcalc.common.config.CacheConfig;
import com.example.fuelcalc.common.exception.ResourceNotFoundException;
import com.example.fuelcalc.vehicle.api.VehicleMapper;
import com.example.fuelcalc.vehicle.api.dto.VehicleRequest;
import com.example.fuelcalc.vehicle.api.dto.VehicleResponse;
import com.example.fuelcalc.vehicle.domain.Vehicle;
import com.example.fuelcalc.vehicle.domain.VehicleService;
import com.example.fuelcalc.vehicle.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class DefaultVehicleService implements VehicleService {

    private final VehicleRepository repository;
    private final VehicleMapper mapper;

    @Override
    public VehicleResponse create(VehicleRequest request) {
        return mapper.toResponse(repository.save(mapper.toEntity(request)));
    }

    @Override
    @Transactional(readOnly = true)
    public VehicleResponse get(Long id) {
        return mapper.toResponse(find(id));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<VehicleResponse> list(Pageable pageable) {
        return repository.findAll(pageable).map(mapper::toResponse);
    }

    @Override
    public VehicleResponse update(Long id, VehicleRequest request) {
        Vehicle vehicle = find(id);
        mapper.update(vehicle, request);
        return mapper.toResponse(repository.save(vehicle));
    }

    @Override
    @CacheEvict(value = CacheConfig.REPORTS, allEntries = true)
    public void delete(Long id) {
        repository.delete(find(id));
    }

    private Vehicle find(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle", id));
    }
}