package com.example.fuelcalc.calculator.domain.strategy;

import com.example.fuelcalc.vehicle.domain.FuelType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CombustionMileageStrategyTest {

    private final CombustionMileageStrategy strategy = new CombustionMileageStrategy();

    @Test
    void calculatesKmPerLitre() {
        assertEquals(15.0, strategy.calculate(450, 30), 0.001);
    }

    @Test
    void supportsOnlyCombustionFuels() {
        assertTrue(strategy.supports(FuelType.PETROL));
        assertTrue(strategy.supports(FuelType.HYBRID));
        assertFalse(strategy.supports(FuelType.ELECTRIC));
    }
}