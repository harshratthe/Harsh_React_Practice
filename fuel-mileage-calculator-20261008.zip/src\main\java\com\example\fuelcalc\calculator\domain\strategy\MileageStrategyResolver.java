package com.example.fuelcalc.calculator.domain.strategy;

import com.example.fuelcalc.common.exception.BusinessRuleException;
import com.example.fuelcalc.vehicle.domain.FuelType;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MileageStrategyResolver {

    private final List<MileageStrategy> strategies;

    public MileageStrategyResolver(List<MileageStrategy> strategies) {
        this.strategies = strategies;
    }

    public MileageStrategy resolve(FuelType fuelType) {
        return strategies.stream()
                .filter(s -> s.supports(fuelType))
                .findFirst()
                .orElseThrow(() -> new BusinessRuleException("No mileage strategy for fuel type: " + fuelType));
    }
}