package com.example.fuelcalc.fuellog.domain;

import com.example.fuelcalc.common.model.BaseEntity;
import com.example.fuelcalc.vehicle.domain.Vehicle;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "fuel_entry")
@Getter
@Setter
@NoArgsConstructor
public class FuelEntry extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;

    @Column(name = "entry_date", nullable = false)
    private LocalDate entryDate;

    @Column(name = "odometer_start", nullable = false)
    private Double odometerStart;

    @Column(name = "odometer_end", nullable = false)
    private Double odometerEnd;

    @Column(name = "fuel_quantity", nullable = false)
    private Double fuelQuantity;

    @Column(name = "price_per_unit", nullable = false)
    private Double pricePerUnit;

    @Column(nullable = false)
    private Double distance;

    @Column(nullable = false)
    private Double mileage;

    @Column(name = "total_cost", nullable = false)
    private Double totalCost;

    public void attachTo(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public void computeDerivedValues() {
        this.distance = odometerEnd - odometerStart;
        this.mileage = distance / fuelQuantity;
        this.totalCost = fuelQuantity * pricePerUnit;
    }
}