package com.example.fuelcalc.calculator.api.dto;

public record TripCostResponse(
        double fuelNeededLitres,
        double estimatedCost,
        String currency
) {}