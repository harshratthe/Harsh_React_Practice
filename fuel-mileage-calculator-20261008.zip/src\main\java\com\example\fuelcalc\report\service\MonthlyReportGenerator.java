package com.example.fuelcalc.report.service;

import com.example.fuelcalc.common.config.FuelCalcProperties;
import com.example.fuelcalc.fuellog.repository.FuelEntryRepository;
import com.example.fuelcalc.report.domain.ReportGenerator;
import com.example.fuelcalc.report.domain.ReportType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class MonthlyReportGenerator implements ReportGenerator {

    private final FuelEntryRepository entryRepository;
    private final FuelCalcProperties props;

    @Override
    public ReportType type() {
        return ReportType.MONTHLY;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> generate(Long vehicleId, LocalDate from, LocalDate to) {
        List<Map<String, Object>> months = new ArrayList<>();

        for (Object[] row : entryRepository.monthlyAggregates(vehicleId, from, to)) {
            double km = ((Number) row[2]).doubleValue();
            double fuel = ((Number) row[3]).doubleValue();
            double cost = ((Number) row[4]).doubleValue();

            Map<String, Object> month = new LinkedHashMap<>();
            month.put("year", ((Number) row[0]).intValue());
            month.put("month", ((Number) row[1]).intValue());
            month.put("distanceKm", round(km));
            month.put("fuel", round(fuel));
            month.put("spent", round(cost));
            month.put("averageMileageKmpl", fuel == 0 ? 0 : round(km / fuel));
            months.add(month);
        }

        Map<String, Object> report = new LinkedHashMap<>();
        report.put("vehicleId", vehicleId);
        report.put("from", from);
        report.put("to", to);
        report.put("currency", props.defaultCurrency());
        report.put("months", months);
        return report;
    }

    private double round(double value) {
        return BigDecimal.valueOf(value).setScale(props.roundingScale(), RoundingMode.HALF_UP).doubleValue();
    }
}