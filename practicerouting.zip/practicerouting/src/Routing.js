import logo from './logo.svg';
import './App.css';
import { Link, Route, Routes } from 'react-router-dom';
import Home from './Home';
import Contact from './Contact';
import Faq from './Faq';

import Login from './LogIn';
import Welcome from './Welcome';
import Payslip from './Payslip';
import ShowPaySlip from './ShowPaySlip';
import { useState } from 'react';
import Ucard from './UCard';
import ShowUser from './ShowUser';
import Protected from './Protected';
const Routing=()=>{



return(<>

<Routes>
  <Route path='/'  element={<Home/>}/>
    <Route path='/Contact'  element={<Contact/>}/>
      <Route path='/faq'  element={<Faq/>}/>
      <Route path='/Login'  element={<Login/>}/>
      <Route path='/Welcome'  element={<Welcome/>}/>
      <Route path='/Payslip'   element={<Payslip/>}/>
      <Route path='/ShowPaySlip' element={<ShowPaySlip/>}/>
            <Route path='/Show' element={<ShowUser/>}/>

      <Route path="/ucard/:UserId/:Name/:Salary" element={<Ucard/>}/>
      <Route path="/faq" element={<Protected Component={Faq} />} />

  </Routes>  



</>)



}
export default Routing