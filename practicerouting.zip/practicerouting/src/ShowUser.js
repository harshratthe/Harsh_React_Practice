import { useNavigate } from "react-router-dom"
import { Link, Route, Routes } from 'react-router-dom';


 

import { useState } from 'react';
import UCard from './UCard';
const ShowUser=()=>
{
 
 
    let [users,setUsers]=useState([{UserId:"101",Name:"asha",Salary:200},
    {UserId:"102",Name:"ajay",Salary:400},
    {UserId:"103",Name:"jatin",Salary:800}
    ,{UserId:"104",Name:"komal",Salary:700}]
  )
 
const nav = useNavigate()
 

    return(<>
 
  <h1>Testing</h1>
 
 
     {
 
   
    d
users.map((temp) => (
  <Link
    key={temp.UserId}
    to={`/ucard/${temp.UserId}/${temp.Name}/${temp.Salary}`}
  >
    <h1>{temp.UserId}</h1>
  </Link>
))   
    
    



    }
 
    
 
 
 
   
    </>)
}
 
export default ShowUser
 