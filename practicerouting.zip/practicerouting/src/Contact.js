import { useNavigate } from "react-router-dom"

const Contact=()=>{



const nav =useNavigate()


const openSignin=()=>{
    nav("/Login")
}




  return(<>
  
  
  <h1>Name-Harsh</h1>
  <h2>Contatc:- harsh@mail.com</h2>
  <button onClick={openSignin}>SignIn</button>
  </>) 



}
export default Contact