import { useParams } from "react-router-dom";

    const Ucard =()=>{

         const { UserId, Name, Salary } = useParams();

return(<>

<h1> {UserId}</h1>
  <h2> {Name}</h2>
  <h2>
    {Salary}
  </h2>
 

</>)

    }
    export default Ucard