import logo from './logo.svg';
import './App.css';
import { Link, Route, Routes } from 'react-router-dom';
import Home from './Home';
import Contact from './Contact';
import Faq from './Faq';

import Login from './LogIn';
import Welcome from './Welcome';
import Payslip from './Payslip';
import ShowPaySlip from './ShowPaySlip';
import { useState } from 'react';
import Ucard from './UCard';
import ShowUser from './ShowUser';
import Routing from './Routing';

const App=()=>{


 
  




  return(<>
 <div>
 
<table border="2"><tr>
  <Link to="/"><td>Home</td></Link>
<Link to="/Contact"><td>Contact</td></Link>
<Link to="/faq"><td>FAQ</td></Link>
<Link to="/Login"><td>Login </td></Link>
<Link to="/Payslip"><td>Calculate Bonus</td></Link>
<Link to= "/Show"><td>Show Users</td></Link>


</tr>
 </table>


<Routing/>


 
   

 </div>
  

   

  
  </>)
}
export default App