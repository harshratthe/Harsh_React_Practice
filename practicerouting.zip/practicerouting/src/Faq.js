const Faq=()=>{


return(<> 

<h1>FAQ</h1>
<h2>Name of the company</h2>
<h3>Company name is Hexaware</h3>


</>)




}
export default Faq