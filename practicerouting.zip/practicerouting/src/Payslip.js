import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Payslip = () => {
  const [Id, setId] = useState("");
  const [Name, setName] = useState("");
  const [Basic, setBasic] = useState(0);

  const usenav = useNavigate();

  const handleId = (e) => setId(e.target.value);
  const handleName = (e) => setName(e.target.value);
  const handleBasic = (e) => setBasic(Number(e.target.value)); // ✅ convert to number

  const Calculate = () => {
    const bonus = Basic > 5000 ? Basic * 0.05 : Basic * 0.1;
    const total = Basic + bonus;

    usenav("/ShowPayslip", {state: { Id, Name, Basic,bonus,Totalsal: total,},});
  };

  return (
    <>
      <input placeholder="Enter Your ID" onChange={handleId} />
      <input placeholder="Enter Your Name" onChange={handleName} />
      <input
        placeholder="Enter Your Basic"
        type="number"
        onChange={handleBasic}
      />
      <button onClick={Calculate}>Calculate</button>
    </>
  );
};

export default Payslip;
