import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const Welcome=()=>{


// let data =useLocation() =>>>> using Navigation 
// let {Id}=data.state
// console.log(data.state)

let [Id,setId]=useState()

useEffect(()=>{

let data=localStorage.getItem("data")
data=JSON.parse(data)
setId(data.Id)
console.log(data.Id)



},[])




return(<>


<h1>Welcome {Id}</h1>

</>)


}
export default Welcome