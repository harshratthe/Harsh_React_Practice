import { useLocation } from "react-router-dom"

const ShowPaySlip=()=>{

let data=useLocation()
let{Id,Name,Basic,Totalsal,bonus}=data.state



return(<>

<h1>Id : {Id}</h1>
<h1>Name : {Name}</h1>
<h1>Basic : {Basic}</h1>
<h1>Bonus  : {bonus}</h1>
<h1>Total Salary : {Totalsal}</h1>







</>)


}
export default ShowPaySlip