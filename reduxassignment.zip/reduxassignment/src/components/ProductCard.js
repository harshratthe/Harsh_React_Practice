const ProductCard = ({ name, price, image, onAdd }) => {
  return (
   <div
      style={{
        border: "1px solid #ccc",
        borderRadius: "12px",
        padding: "15px",
        margin: "15px",
        textAlign: "center",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        transition: "transform 0.2s",
        maxWidth: "200px",
        backgroundColor: "#fefefe"
      }}
      onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.03)")}
      onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
    >
      <img src={image} alt={name} style={{ width: "150px", height: "150px" }} />
      <h3>{name}</h3>
      <p>₹{price}</p>
      <button onClick={onAdd}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;