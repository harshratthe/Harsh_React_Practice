import FlowerList from "./components/FlowerList";
import WatchList from "./components/WatchList";
import Billing from "./components/Biling";

function App() {
  return (
    <div>
      <h1>Online  Store</h1>
      <WatchList />
      <FlowerList />
      <Billing />
    </div>
  );
}

export default App;