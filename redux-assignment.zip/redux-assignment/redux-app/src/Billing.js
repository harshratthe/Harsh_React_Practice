import { useSelector } from 'react-redux';

const Billing = () => {
  const cart = useSelector((state) => state.cart.cartItems);

  const grouped = cart.reduce((acc, item) => {
    acc[item.id] = acc[item.id] || { ...item, qty: 0 };
    acc[item.id].qty += 1;
    return acc;
  }, {});

  const groupedItems = Object.values(grouped);
  const total = groupedItems.reduce((sum, item) => sum + item.price * item.qty, 0);

  return (
    <div style={{ padding: 20 }}>
      <h2>Bill Summary</h2>
      {groupedItems.map((item) => (
        <div key={item.id}>
          <p>
            {item.name} x {item.qty} = ₹{item.price * item.qty}
          </p>
        </div>
      ))}
      <h3>Total: ₹{total}</h3>
    </div>
  );
};

export default Billing;
