import Billing from "./Billing";
import FlowerList from "./FlowerList";
import WatchList from "./WatchList";

const App = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Shopping Cart App</h1>
      <FlowerList/>
      <WatchList/>
      <Billing/>
    </div>
  );
};

export default App;
