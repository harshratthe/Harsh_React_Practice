import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import axios from 'axios';

function App() {


let[actno,setAct]=useState()
let[name,setName]=useState()
let[balance,setBalance]=useState()
let[type,setType]=useState()
let[msg,setMsg]=useState("")
let[amt,setAmt]=useState()
let[showdata,setShowdata]=useState()




const saveData=async () => {
  let data={actno,name,balance,type}
  const res=await axios.post("http://localhost:8085/saveData",data) 
  setMsg(res.data)
}

const removeData=async () => {
    let res= await axios.delete(`http://localhost:8085/getDelete/${actno}`)
        setMsg(res.data)
}

const Deposit=async()=>
   {
     let res= await axios.put(`http://localhost:8085/deposit/${actno}/${amt}`)
        setMsg(res.data)
 
   }

const searchData=async () => {
  let res=await axios.get(`http://localhost:8085/getData/${actno}`)
  setShowdata(res.data)

}



  return (
    <div >
      <input type="text"  placeholder='Enter Account No' onChange={(e)=>setAct(e.target.value)}/>
            <input type="text"  placeholder='Enter Name' onChange={(e)=>setName(e.target.value)}/>
      <input type="text"  placeholder='Enter Balance' onChange={(e)=>setBalance(e.target.value)}/>
      <input type="text"  placeholder='Enter Account type' onChange={(e)=>setType(e.target.value)}/>
            <input type="text"  placeholder='Enter Amount' onChange={(e)=>setAmt(e.target.value)}/>

      <button onClick={saveData}> Save Data </button>

      <button onClick={removeData}>Delete Account</button>
      <button onClick={Deposit}>Deposit</button>
      <button onClick={searchData}>Search BY ID</button>
      
     <h2>{showdata?.actno}</h2>
          <h2>{showdata?.name}</h2>
               <h2>{showdata?.balance}</h2>
                    <h2>{showdata?.type}</h2>




    </div>
  );
}

export default App;
